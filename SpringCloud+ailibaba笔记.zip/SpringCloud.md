











# SpringCloud

**关于springcloud部分组件的升级和停更**

1. 服务注册中心：Eureka停用,可以使用zk,**Nacos**作为服务注册中心
2. 服务调用： Ribbon准备停更,代替为LoadBalance
3. 服务调用2：Feign改为OpenFeign
4. 服务降级：Hystrix停更,国外用resilence4j，国内推荐阿里巴巴的**sentienl**
5. 服务网关：Zuul改为gateway
6. 服务配置：Config改为  **Nacos**
7. 服务总线：Bus改为 **Nacos**
8. ![image-20200606174817091](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606174817091.png)

---



==**记住 ：约定  >配置  >编码 **== 



## 环境搭建



		#### 父工程搭建

​	选择脚手架搭建

![image-20200530101818731](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530101818731.png)



![image-20200530102916823](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530102916823.png)

maven要3.5以上

![image-20200530102504186](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530102504186.png)



统一字符编码

![image-20200530104617457](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530104617457.png)

注解激活生效

![image-20200530110142515](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530110142515.png)

选择java8编译

![image-20200530110330438](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530110330438.png)



File  Type 过滤，个人习惯不选择也行，那个*.idel 打逗号是错的 是打==;== 分隔

![image-20200530110838533](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530110838533.png)

----



#### 父工程pom依赖统一管理

~~~xml
<!-- 统一管理jar包版本 -->
    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>1.8</maven.compiler.source>
        <maven.compiler.target>1.8</maven.compiler.target>
        <junit.version>4.12</junit.version>
        <log4j.version>1.2.17</log4j.version>
        <lombok.version>1.16.18</lombok.version>
        <mysql.version>5.1.47</mysql.version>
        <druid.version>1.1.16</druid.version>
        <mybatis.spring.boot.version>1.3.0</mybatis.spring.boot.version>
    </properties>

    <!-- 子模块继承之后，提供作用：锁定版本+子modlue不用写groupId和version  -->
    <dependencyManagement>
        <dependencies>
            <!--spring boot 2.2.2-->
            <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-dependencies</artifactId>
                <version>2.2.2.RELEASE</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
            <!--spring cloud Hoxton.SR1-->
            <dependency>
                <groupId>org.springframework.cloud</groupId>
                <artifactId>spring-cloud-dependencies</artifactId>
                <version>Hoxton.SR1</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
            <!--spring cloud alibaba 2.1.0.RELEASE-->
            <dependency>
                <groupId>com.alibaba.cloud</groupId>
                <artifactId>spring-cloud-alibaba-dependencies</artifactId>
                <version>2.1.0.RELEASE</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
            <dependency>
                <groupId>mysql</groupId>
                <artifactId>mysql-connector-java</artifactId>
                <version>${mysql.version}</version>
            </dependency>
            <dependency>
                <groupId>com.alibaba</groupId>
                <artifactId>druid</artifactId>
                <version>${druid.version}</version>
            </dependency>
            <dependency>
                <groupId>org.mybatis.spring.boot</groupId>
                <artifactId>mybatis-spring-boot-starter</artifactId>
                <version>${mybatis.spring.boot.version}</version>
            </dependency>
            <dependency>
                <groupId>junit</groupId>
                <artifactId>junit</artifactId>
                <version>${junit.version}</version>
            </dependency>
            <dependency>
                <groupId>log4j</groupId>
                <artifactId>log4j</artifactId>
                <version>${log4j.version}</version>
            </dependency>
            <dependency>
                <groupId>org.projectlombok</groupId>
                <artifactId>lombok</artifactId>
                <version>${lombok.version}</version>
                <optional>true</optional>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <configuration>
                    <fork>true</fork>
                    <addResources>true</addResources>
                </configuration>
            </plugin>
        </plugins>
    </build>
~~~

父工程完成创建执行mvn:install,将父工程发布到仓库，方便子工程继承。	



#### Rest微服务工程构建

1.cloud-provider-payment8001   微服务提供者支付Module模块

2.改pom 添加依赖

~~~xml
 <dependencies>
        <!--包含了sleuth+zipkin-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-zipkin</artifactId>
        </dependency>
        <!--eureka-client-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
        <dependency><!-- 引入自己定义的api通用包，可以使用Payment支付Entity -->
            <groupId>com.atguigu.springcloud</groupId>
            <artifactId>cloud-api-commons</artifactId>
            <version>${project.version}</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
        </dependency>
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid-spring-boot-starter</artifactId>
            <version>1.1.10</version>
        </dependency>
        <!--mysql-connector-java-->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
        </dependency>
        <!--jdbc-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-jdbc</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
~~~

 3.创建application.yml文件

~~~yml
server:
  port: 8001

spring:
  application:
    name: cloud-payment-service
  zipkin:
      base-url: http://localhost:9411
  sleuth:
    sampler:
    #采样率值介于 0 到 1 之间，1 则表示全部采集
    probability: 1
  datasource:
    type: com.alibaba.druid.pool.DruidDataSource            # 当前数据源操作类型
    driver-class-name: org.gjt.mm.mysql.Driver              # mysql驱动包
    url: jdbc:mysql://localhost:3306/db2019?useUnicode=true&characterEncoding=utf-8&useSSL=false
    username: root
    password: 123456


eureka:
  client:
    #表示是否将自己注册进EurekaServer默认为true。
    register-with-eureka: true
    #是否从EurekaServer抓取已有的注册信息，默认为true。单节点无所谓，集群必须设置为true才能配合ribbon使用负载均衡
    fetchRegistry: true
    service-url:
      #单机版
      defaultZone: http://localhost:7001/eureka
      # 集群版
      #defaultZone: http://eureka7001.com:7001/eureka,http://eureka7002.com:7002/eureka
  instance:
      instance-id: payment8001
      #访问路径可以显示IP地址
      prefer-ip-address: true
      #Eureka客户端向服务端发送心跳的时间间隔，单位为秒(默认是30秒)
      #lease-renewal-interval-in-seconds: 1
      #Eureka服务端在收到最后一次心跳后等待时间上限，单位为秒(默认是90秒)，超时将剔除服务
      #lease-expiration-duration-in-seconds: 2


mybatis:
  mapperLocations: classpath:mapper/*.xml
  type-aliases-package: com.atguigu.springcloud.entities    # 所有Entity别名类所在包
~~~

4.创建主程序

~~~java
@SpringBootApplication
public class PaymentMain8001 {
    public static void main(String[] args) {
        SpringApplication.run(PaymentMain8001.class,args);
    }
}
~~~

5.编写业务类(自己手写)

- 建表SQL

- entities

- dao

- service

- controller

---



####热部署Devtools

1.在需要的项目里添加

~~~xml
 <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>在父pom中添加一个插件
~~~

2.在父pom中添加一个插件

```xml
 <build>
    <plugins>
      <plugin>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-maven-plugin</artifactId>
        <configuration>
          <fork>true</fork>
          <addResources>true</addResources>
        </configuration>
      </plugin>
    </plugins>
  </build>
```

3.Enabling automatic build,下面的打钩！

![image-20200530222416733](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530222416733.png)

 

4.Update the value of

- 按下 Ctrl+shift+Alt+/

- ![image-20200530222758454](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530222758454.png)

- ![image-20200530223149645](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530223149645.png)

- ![image-20200530223311285](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200530223311285.png)

  5.重启IDEA

  ----







**微服务消费者订单Module模块：cloud-consumer-order80** 

1.添加pom依赖

```xml
 <dependencies>
        <!--包含了sleuth+zipkin-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-zipkin</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
        <dependency><!-- 引入自己定义的api通用包，可以使用Payment支付Entity -->
            <groupId>com.atguigu.springcloud</groupId>
            <artifactId>cloud-api-commons</artifactId>
            <version>${project.version}</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
```

2.编写application.yml

~~~yml
server:
  port: 80

~~~

跟上一个工程类似，就不在编写！！！！

编写一个config 配置RestTemplate

```java
@Configuration
public class ApplicationContextConfig {

    @Bean
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }
}

```

编写controller

```java
@RestController
@Slf4j
public class OrderController {
    public static  final String PAYMENT_URL="http://localhost:/8001";

    @Resource
    private RestTemplate restTemplate;

    @GetMapping("/consumer/payment/create")
    public CommonResult<Payment> create(Payment payment) {

        return restTemplate.postForObject(PAYMENT_URL+"/payment/create",payment,CommonResult.class);
    }

    @GetMapping("/consumer/payment/get/{id}")
    public CommonResult<Payment> getPayment(@PathVariable("id") Long id){

        return restTemplate.getForObject(PAYMENT_URL+"/payment/get/"+id,CommonResult.class);

    }

}

```

----







## Eureka服务注册与发现

#### Eureka的基础知识

- 什么是服务治理
  - ![image-20200601093440491](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200601093440491.png)

- 什么是服务注册
  - ![image-20200601094002188](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200601094002188.png)
  - ![image-20200601094042619](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200601094042619.png)

- Eureka的两个组件
- ![image-20200601094701935](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200601094701935.png)





#### 单机Eureka构建

- 建Module  cloud-eureka-server7001
- 添加pom依赖

~~~xml
<dependencies>
        <!--eureka-server-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
        </dependency>
        <!-- 引入自己定义的api通用包，可以使用Payment支付Entity -->
        <dependency>
            <groupId>com.atguigu.springcloud</groupId>
            <artifactId>cloud-api-commons</artifactId>
            <version>${project.version}</version>
        </dependency>
        <!--boot web actuator-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        <!--一般通用配置-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
        </dependency>
    </dependencies>
~~~

- yml文件

~~~yml
server:
  port: 7001
eureka:
  instance:
    hostname: localhost #eureka服务端实例的名字
  #表示 不在注册中心注册自己
  client:
    register-with-eureka: false
    #自己是服务端不用自己注册自己，只需要维护服务实例
    fetch-registry: false
    service-url:
      #设置与eureka server 交互地址查询，服务和注册 都需要依赖这个地址
      defaultZone: http://${eureka.instance.hostname}:${server.port}/eureka/   
      #相当于  http:localhost:7001/eureka/
~~~

- 启动类

~~~java
@SpringBootApplication
@EnableEurekaServer
public class EurekaMain7001 {

    public static void main(String[] args) {
        SpringApplication.run(EurekaMain7001.class,args);
    }
}
~~~



#### 集群Eureka搭建步骤

集群原理说明

![image-20200601210319773](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200601210319773.png)

解决办法：搭建Eureka注册中心集群，实现负载均衡，故障容错

- 新建 cloud-eureka-server7002
- 修改映射配置文件       C:\Windows\System32\drivers\etc\host

~~~shell
#在文件里添加
127.0.0.1  eureka7001.com
127.0.0.1  eureka7002.com
~~~

修改7001yml

~~~yml
server:
  port: 7001
eureka:
  instance:
    hostname: eureka7001.com #eureka服务端实例的名字
  #表示 不在注册中心注册自己
  client:
    register-with-eureka: false
    #自己是服务端不用自己注册自己，只需要维护服务实例
    fetch-registry: false
    service-url:
      #设置与eureka server 交互地址查询，服务和注册 都需要依赖这个地址
      defaultZone: http://eureka7002.com:7002/eureka/


~~~

修改7002yml

```yml
server:
  port: 7002
eureka:
  instance:
    hostname: eureka7002.com #eureka服务端实例的名字
  #表示 不在注册中心注册自己
  client:
    register-with-eureka: false
    #自己是服务端不用自己注册自己，只需要维护服务实例
    fetch-registry: false
    service-url:
      #设置与eureka server 交互地址查询，服务和注册 都需要依赖这个地址
      defaultZone: http://eureka7001.com:7002/eureka/


```

将8001和80注册进两台服务器

~~~yml
defaultZone: http://eureka7001.com:7001/eureka,http://eureka7002.com:7002/eureka
~~~

---



#### 支付模块微服务集群配置

- **前面几个跟上面类似，参照上面**

- 在controller加上

![image-20200601231802427](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200601231802427.png)

在消费者端口把主机端口改下应为写死了！

![image-20200601231944089](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200601231944089.png)

这个时候直接访问会报错

![image-20200601232022414](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200601232022414.png)

因为是对外暴露服务，不是直接暴露端口，不知道该调用那一条服务所以报错

在配置类上加上

~~~java
@Configuration
public class ApplicationContextConfig {

    @Bean
    @LoadBalanced   //给RestTemlate赋予负载均衡  
    public RestTemplate getRestTemplate(){
        return new RestTemplate();
    }

~~~

---





#### actuator微服务信息完善

---



- 主机名称，服务名称修改

在eureka.client下面添加

~~~yml
instance:
    instance-id: payment8002    #修改主机的ID 也就是名字
    prefer-ip-address: true		#显示主机的IP地址
~~~

![image-20200602091318633](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602091318633.png)



#### 服务发现Discovery

---



==功能：对于注册eureka里面的微服务，可以通过服务发现来获取服务的信息== 

在支付服务提供者的controller里添加  一个方法   在启动类上添加 @EnableDiscoveryClient

~~~java
 @Resource
    private DiscoveryClient discoveryClient;


 @GetMapping("/payment/discovery")
    public Object discovery(){
        List<String> services = discoveryClient.getServices();
        for (String element : services) {
            log.info("*********element:"+element);
        }
        List<ServiceInstance> instances = discoveryClient.getInstances("CLOUD-PAYMENT-SERVICE");
        for (ServiceInstance instance : instances) {
            log.info(instance.getServiceId()+"\t"+instance.getHost()+"\t"+instance.getPort()+"\t"+instance.getUri());
        }
       return this.discoveryClient;
    }
~~~



![image-20200602103430385](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602103430385.png)

#### Eureka自我保护

----

##### 自我保护理论知识

- 故障现象

![image-20200602104938997](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602104938997.png)

一句话：某个时刻某一个微服务不可用了，Eureka不会立刻清理，依旧会对该服务的信息进行保存

属于CPA里面的AP分支

- 导致原因

![image-20200602105638400](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602105638400.png)

![image-20200602105709400](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602105709400.png)

![image-20200602105858125](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602105858125.png) 

##### 关闭自我保护

在服务注册yml中添加

~~~yml
server:
    enable-self-preservation: false   #是否开启自我保护 默认开启
    eviction-interval-timer-in-ms: 2000  #如果两秒没有接受注册到服务的信息，注册中心将会剔除该服务
~~~

![image-20200602112120072](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602112120072.png)

已经关闭

在服务提供的yml中修改

~~~yml
instance:
    lease-renewal-interval-in-seconds: 1    #Eureka客户端向服务端发送心跳间隔时间  默认30秒
    lease-expiration-duration-in-seconds: 2		#Eureka在收到最后一次心跳等待时间上限（默认90秒）超时就剔除
~~~



## Zookeeper做服务注册 中心

1. 建moudle cloud-provider-payment8004
2. 添加pom依赖

~~~xml
   		 <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-zookeeper-discovery</artifactId>
            <version>2.2.0.RELEASE</version>
        </dependency>
~~~

修改yml文件

~~~yml
server:
  port: 8004

spring:
  application:
    name: cloud-provider-payment
  cloud:
    zookeeper:
      connect-string: 192.168.43.237:2181

~~~

启动类

~~~java
@SpringBootApplication
@EnableDiscoveryClient
public class PaymentMain8004 {

    public static void main(String[] args) {
        SpringApplication.run(PaymentMain8004.class,args);
    }
}

~~~

controller

~~~java
@RestController
@Slf4j
public class PaymentController
{
    @Value("${server.port}")
    private String serverPort;

    @RequestMapping(value = "/payment/zk")
    public String paymentzk()
    {
        return "springcloud with zookeeper: "+serverPort+"\t"+ UUID.randomUUID().toString();
    }
}
~~~

---







## Consul



#### Consul是什么？

Consul官网：https://www.consul.io/intro

![image-20200602170522018](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602170522018.png)

**Consul怎么玩 ，中文版的  https://www.springcloud.cc/spring-cloud-consul.html** 

####Consul安装

下载地址：https://www.consul.io/downloads.html

下载完成解压

运行 consul --version 查看版本

开发模式启动

![image-20200602172558746](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602172558746.png)

在浏览器输入localhost:8500

![image-20200602172749623](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602172749623.png)

新建Module支付服务provider8006    cloud-providerconsul-payment8006

添加依赖

~~~xml
  <dependencies>
        <!-- https://mvnrepository.com/artifact/org.springframework.cloud/spring-cloud-starter-consul-discovery -->
        <dependency>
           <groupId>org.springframework.cloud</groupId>
           <artifactId>spring-cloud-starter-consul-discovery</artifactId>
       </dependency>

       <dependency>
           <groupId>com.atguigu.springcloud</groupId>
           <artifactId>cloud-api-commons</artifactId>
           <version>${project.version}</version>
       </dependency>


        <!-- https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-web -->
        <dependency>
           <groupId>org.springframework.boot</groupId>
           <artifactId>spring-boot-starter-web</artifactId>
       </dependency>

        <!-- https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-web -->
        <dependency>
           <groupId>org.springframework.boot</groupId>
           <artifactId>spring-boot-starter-actuator</artifactId>
       </dependency>

        <!-- https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-devtools -->
        <dependency>
           <groupId>org.springframework.boot</groupId>
           <artifactId>spring-boot-devtools</artifactId>
           <scope>runtime</scope>
           <optional>true</optional>
       </dependency>

        <!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->
        <dependency>
           <groupId>org.projectlombok</groupId>
           <artifactId>lombok</artifactId>
           <optional>true</optional>
       </dependency>

        <!-- https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-test -->
        <dependency>
           <groupId>org.springframework.boot</groupId>
           <artifactId>spring-boot-starter-test</artifactId>
           <scope>test</scope>
       </dependency>



   </dependencies>
~~~

yml

~~~yml
server:
  port: 8006


spring:
  application:
    name: consul-provider-payment
  cloud:
    consul:
      host: localhost
      port: 8500
      discovery:
        service-name: ${spring.application.name}


~~~

新建消费者cloud-consumerconsul-order80

跟上面类似

---



## 三个注册中心的异同点

![image-20200602203548087](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602203548087.png)

![image-20200602203612649](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602203612649.png)

**CAP**

- C:Consistency(强一致性)
- A:Availability(可用性)
- P:Partition tolerance(分区容错)
- CAP理论关注粒度是数据，而不是整体系统设计的策略

![image-20200602205536986](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602205536986.png)

AP  :Eureka

CP :Zookeeper,consul

简单点就是：CP 要保证数据的一致性，一旦服务断了或者数据不同步时就返回错误，

AP：保证服务的高可用，宁愿有一点失误

---





## Ribbon负载均衡服务调用

####概述：

![image-20200602212921522](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602212921522.png)

官网资料：https://github.com/Netflix/ribbon/wiki/Getting-Started



####能干嘛：LB（Load Balancer）负载均衡

- 负载均衡分为：集中式LB   进程内LB
- ![image-20200602214418387](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602214418387.png)
- ![image-20200602214538633](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602214538633.png)

![image-20200602213859630](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602213859630.png)

什么是Ribbon一句话：就是负载均衡+RestTemplate调用



![image-20200602220318490](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602220318490.png)

**架构说明**

![image-20200602220341406](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602220341406.png)

![image-20200602220448259](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602220448259.png)

**RestTemplate的使用**

- getForObject方法/getForEntity
- postForObject方法/postForEntity
- ![image-20200602221340329](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602221340329.png)

#### Ribbon核心组件IRule

- IRule:根据特定算法从服务列表中选取一个要访问的服务

![image-20200602222801171](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602222801171.png)

**如何替换**

- 注意配置细节
- ![image-20200602223541699](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602223541699.png)

![image-20200602223625083](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602223625083.png)

- 新建package  com.atguigu.myrule
- 在里面见一个规则类

~~~java
@Configuration
public class MySelfRule {

    @Bean
    public IRule myRule(){
        return new RandomRule();  //定义为随机
    }
}
~~~



在启动类上面添加：

~~~java
@RibbonClient(name = "CLOUD-PAYMENT-SERVICE",configuration = MySelfRule.class)
~~~



#### ==Riboon负载均衡算法==

---

原理：

![image-20200602230541660](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200602230541660.png)



#### ==Ribbon手写轮循算法== 

1.在8001,8002，controller里面添加

~~~java
@GetMapping(value = "/payment/lb")
    public String getPaymentLB(){
        return serverPort;
    }
~~~

2.注释 配置类 的负载均衡

  ![image-20200603094708616](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200603094708616.png)

建一个接口  lb.LoadBalancer

```java
package com.atguigu.springcloud.lb;

import org.springframework.cloud.client.ServiceInstance;

import java.util.List;

public interface LoadBalancer {
    ServiceInstance  instance (List<ServiceInstance> serviceInstances);
}

```



实现类

~~~java
package com.atguigu.springcloud.config;

import com.atguigu.springcloud.lb.LoadBalancer;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
@Component
public class MyLB implements LoadBalancer {
    private AtomicInteger atomicInteger = new AtomicInteger(0);

    public final int getAndIncrement() {
        int current;
        int next;
        do {
            current = this.atomicInteger.get();
            next = current > 2147483647 ? 0 : current + 1;

        } while (!this.atomicInteger.compareAndSet(current, next));
        System.out.println("*********第几次访问，次数next" + next);
        return next;

    }

    @Override
    public ServiceInstance instance(List<ServiceInstance> serviceInstances) {
        int index = getAndIncrement() % serviceInstances.size();
        return serviceInstances.get(index);
    }
}

~~~

80controller

~~~java
package com.atguigu.springcloud.controller;

import com.atguigu.springcloud.entities.CommonResult;
import com.atguigu.springcloud.entities.Payment;
import com.atguigu.springcloud.lb.LoadBalancer;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.weaver.ast.Var;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.net.URI;
import java.util.List;

@RestController
@Slf4j
@SuppressWarnings("unchecked")
public class OrderController {
    //public static  final String PAYMENT_URL="http://localhost:8001";
    public static  final String PAYMENT_URL="http://CLOUD-PAYMENT-SERVICE";

    @Resource
    private RestTemplate restTemplate;

    @Resource
    private LoadBalancer loadBalancer;
    @Resource
    private DiscoveryClient discoveryClient;

    @GetMapping("/consumer/payment/create")
    public CommonResult<Payment> create(Payment payment) {

        return restTemplate.postForObject(PAYMENT_URL+"/payment/create",payment,CommonResult.class);
    }

    @GetMapping("/consumer/payment/get/{id}")
    public CommonResult<Payment> getPayment(@PathVariable("id") Long id){

        return restTemplate.getForObject(PAYMENT_URL+"/payment/get/"+id,CommonResult.class);

    }

    @GetMapping("/consumer/payment/lb")
    public String  getPaymentLB(){
        List<ServiceInstance> instances = discoveryClient.getInstances("CLOUD-PAYMENT-SERVICE");
        if(instances ==null || instances.size()<=0){
            return  null;
        }
        ServiceInstance instance = loadBalancer.instance(instances);
        URI uri = instance.getUri();
        return  restTemplate.getForObject(uri+"/payment/lb",String.class);
    }

}

~~~

---









## OpenFeign

#### OpenFeign是什么？

Feign是一个声明式的web服务客户端，让编写web服务客户端变得非常容易，只需创建一个接口并在接口上添加注解即可

![image-20200603110452168](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200603110452168.png)

GitHub:https://github.com/spring-cloud/spring-cloud-openfeign

#### 能干嘛

![image-20200603110832780](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200603110832780.png)

#### Feign和OpenFeign的区别

![image-20200603111208139](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200603111208139.png)



####新的消费者服务   cloud-consumer-feign-order80

pom依赖

~~~xml
 <dependencies>
        <!--openfeign-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-openfeign</artifactId>
        </dependency>
        <!--eureka client-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
        <!-- 引入自己定义的api通用包，可以使用Payment支付Entity -->
        <dependency>
            <groupId>com.atguigu.springcloud</groupId>
            <artifactId>cloud-api-commons</artifactId>
            <version>${project.version}</version>
        </dependency>
        <!--web-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        <!--一般基础通用配置-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
~~~

yml

~~~yml
server:
  port: 80

eureka:
  client:
    register-with-eureka: false
    service-url:
      defaultZone: http://eureka7001.com:7001/eureka/,http://eureka7002.com:7002/eureka/
#设置feign客户端超时时间(OpenFeign默认支持ribbon)
ribbon:
#指的是建立连接所用的时间，适用于网络状况正常的情况下,两端连接所用的时间
  ReadTimeout: 5000
#指的是建立连接后从服务器读取到可用资源所用的时间
  ConnectTimeout: 5000

logging:
  level:
    # feign日志以什么级别监控哪个接口
    com.atguigu.springcloud.service.PaymentFeignService: debug

~~~

主启动类

~~~java
@SpringBootApplication
@EnableFeignClients
public class OrderFeignMain80 {

    public static void main(String[] args) {
        SpringApplication.run(OrderFeignMain80.class);
    }
}

~~~

service

~~~java
@FeignClient(value = "CLOUD-PAYMENT-SERVICE")
@Component
public interface PaymentFeignService {

    @GetMapping("/payment/get/{id}")
    public CommonResult<Payment> create(@PathVariable("id") Long id);

}
~~~

contoller

~~~java
/**
 * @auther zzyy
 * @create 2020-02-20 0:05
 */
@RestController
@Slf4j
public class OrderFeignController
{
    @Resource
    private PaymentFeignService paymentFeignService;

    @GetMapping(value = "/consumer/payment/get/{id}")
    public CommonResult<Payment> getPaymentById(@PathVariable("id") Long id)
    {
        return paymentFeignService.getPaymentById(id);
    }


}

~~~

OpenFeign的超时控制

~~~yml
#设置feign客户端超时时间(OpenFeign默认支持ribbon)
ribbon:
#指的是建立连接所用的时间，适用于网络状况正常的情况下,两端连接所用的时间
  ReadTimeout: 5000
#指的是建立连接后从服务器读取到可用资源所用的时间
  ConnectTimeout: 5000

~~~

OpenFeign的日志打印功能

![image-20200603220208885](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200603220208885.png)

日志级别:

![image-20200603220301457](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200603220301457.png)

~~~yml
logging:
  level:
    # feign日志以什么级别监控哪个接口
    com.atguigu.springcloud.service.PaymentFeignService: debug
~~~



添加一个配置类

~~~java
@Configuration
public class FeignConfig {

    @Bean
    Logger.Level feignLoggerLeve(){
        return Logger.Level.FULL;
    }
}

~~~

![image-20200603220719858](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200603220719858.png)





---











## Hystrix



#### Hystrix是什么

![image-20200604093544215](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200604093544215.png)

![image-20200604093640721](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200604093640721.png)



![image-20200604093730751](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200604093730751.png)





#### 作用：

服务降级（fallback）

![image-20200604100420190](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200604100420190.png)

![image-20200604100446980](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200604100446980.png)

服务熔断(break)

![image-20200604100549095](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200604100549095.png)

![image-20200604102152504](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200604102152504.png)

接近实时的监控

服务限流(flowlimit)

![image-20200604102105061](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200604102105061.png)

官网资料：https://github.com/Netflix/Hystrix/wiki/How-To-Use





---

#### Hystrix案例

新建    cloud-provider-hystrix-payment8001

~~~xml
<dependencies>
        <!--hystrix-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-hystrix</artifactId>
        </dependency>
        <!--eureka client-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
        <!--web-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        <dependency><!-- 引入自己定义的api通用包，可以使用Payment支付Entity -->
            <groupId>com.atguigu.springcloud</groupId>
            <artifactId>cloud-api-commons</artifactId>
            <version>${project.version}</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

~~~

~~~yml
server:
  port: 8001

spring:
  application:
    name: cloud-provider-hystrix-payment
  #   eviction-interval-timer-in-ms: 2000

eureka:
  client:
    register-with-eureka: true    #表识不向注册中心注册自己
    fetch-registry: true   #表示自己就是注册中心，职责是维护服务实例，并不需要去检索服务
    service-url:
      # defaultZone: http://eureka7002.com:7002/eureka/   #设置与eureka server交互的地址查询服务和注册服务都需要依赖这个地址
      defaultZone: http://eureka7001.com:7001/eureka/
# server:
#   enable-self-preservation: false


~~~

启动类

~~~java
@SpringBootApplication
@EnableEurekaClient
public class PaymentHystrixMain8001 {

    public static void main(String[] args) {
        SpringApplication.run(PaymentHystrixMain8001.class,args);
    }
}

~~~

service

~~~java
@Service
public class PaymentService
{
    /**
     * 正常访问，肯定OK
     * @param id
     * @return
     */
    public String paymentInfo_OK(Integer id)
    {
        return "线程池:  "+Thread.currentThread().getName()+"  paymentInfo_OK,id:  "+id+"\t"+"O(∩_∩)O哈哈~";
    }

    public String paymentInfo_Timeout(Integer id){
        int timeOut=3;
        try {
            TimeUnit.SECONDS.sleep(timeOut);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "线程池"+Thread.currentThread().getName()+"paymentInfo_Timeout："+id +"\t"+"O(∩_∩)O哈哈~"+"耗时（秒）"+timeOut;
    }

}
~~~

高并发测试

![image-20200605151704773](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200605151704773.png)

![image-20200605151715358](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200605151715358.png)

![image-20200605151740429](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200605151740429.png)

对方8001服务OK 调用者自己故障或者有自我要求（自己等待的时间小于服务提供者）自己降级处理

**降级配置**

![image-20200605153657656](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200605153657656.png)

![image-20200605154215395](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200605154215395.png)

8001 service

~~~java
 @HystrixCommand(fallbackMethod = "paymentInfo_TimeoutHandler",
    commandProperties = {
            @HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value = "3000")
    })
    public String paymentInfo_Timeout(Integer id){
        int timeOut=5;
        try {
            TimeUnit.SECONDS.sleep(timeOut);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "线程池"+Thread.currentThread().getName()+"paymentInfo_Timeout："+id +"\t"+"O(∩_∩)O哈哈~"+"耗时（秒）"+timeOut;
    }

    public String paymentInfo_TimeoutHandler(Integer id){

        return "线程池"+Thread.currentThread().getName()+"paymentInfo_TimeoutHandler："+id +"\t"+"o(╥﹏╥)o";
    }

~~~

在主启动类上加上  @EnableCircuitBreaker

![image-20200605160341558](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200605160341558.png)

![image-20200605172738305](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200605172738305.png)

**配置通用fallback,因为每个方法都写一个降级的方法太麻烦，除了个别需要定制的，一般就使用全局默认的降级方法**

![image-20200605214400167](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200605214400167.png)

~~~java
@RestController
@Slf4j
@DefaultProperties(defaultFallback = "payment_Global_FallbackMethod")
public class OrderHystixController {

    @Resource
    private PaymentHystrixService paymentHystrixService;

  

    @GetMapping("/consumer/hystrix/timeout/{id}")
    /*@HystrixCommand(fallbackMethod ="paymentInfo_TimeoutHandler",commandProperties = {
            @HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value = "1500")
    })*/
   @HystrixCommand
    public String paymentInfo_timeout(@PathVariable("id") Integer id){
        int i = 10/0;
        String result = paymentHystrixService.paymentInfo_timeout(id);
        return result;
    }


    // 下面是全局fallback方法
    public String payment_Global_FallbackMethod()
    {
        return "Global异常处理信息，请稍后再试，/(ㄒoㄒ)/~~";
    }
}

~~~

#### 服务降级

![image-20200606094119597](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606094119597.png)

![image-20200606094235857](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606094235857.png)

根据cloud-consumer-feign-hystrix-order80已经有的PaymentHystrixService接口，重新新建一个类（PaymentFallbackService）实现该接口，统一为接口里面的方法进行异常处理

PaymentFallbackService类实现PaymentFeignClientService接口

```java
@FeignClient(value = "CLOUD-PROVIDER-HYSTRIX-PAYMENT",fallback = PaymentFallbackService.class)
```



#### 服务熔断

![image-20200606113221008](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606113221008.png)

大神论文  https://martinfowler.com/bliki/CircuitBreaker.html



在8001service添加

~~~java
//=====服务熔断
    @HystrixCommand(fallbackMethod = "paymentCircuitBreaker_fallback",commandProperties = {
            @HystrixProperty(name = "circuitBreaker.enabled",value = "true"),// 是否开启断路器
            @HystrixProperty(name = "circuitBreaker.requestVolumeThreshold",value = "10"),// 请求次数
            @HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds",value = "10000"), // 时间窗口期
            @HystrixProperty(name = "circuitBreaker.errorThresholdPercentage",value = "60"),// 失败率达到多少后跳闸
    })
    public String paymentCircuitBreaker(@PathVariable("id") Integer id)
    {
        if(id < 0)
        {
            throw new RuntimeException("******id 不能负数");
        }
        String serialNumber = IdUtil.simpleUUID();

        return Thread.currentThread().getName()+"\t"+"调用成功，流水号: " + serialNumber;
    }
    public String paymentCircuitBreaker_fallback(@PathVariable("id") Integer id)
    {
        return "id 不能负数，请稍后再试，/(ㄒoㄒ)/~~   id: " +id;
    }
~~~

断路器在什么时候起作用

![image-20200606174116460](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606174116460.png)

断路器开启或关闭的条件

![image-20200606174352909](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606174352909.png)

断路器打开之后

![image-20200606174514378](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606174514378.png)

#### hystrix工作流程

https://github.com/Netflix/Hystrix/wiki/How-it-Works

 

#### 服务监控hystrixDashboard

概述：

![image-20200606213438886](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606213438886.png)



新建Model cloud-consumer-hystrix-dashboard9001

pom

~~~xml
   <dependencies>
        <!--新增hystrix dashboard-->
        <dependency>
           <groupId>org.springframework.cloud</groupId>
           <artifactId>spring-cloud-starter-netflix-hystrix-dashboard</artifactId>
       </dependency>
       <dependency>
            <groupId>org.springframework.boot</groupId>
           <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>

       <dependency>
           <groupId>org.springframework.boot</groupId>
           <artifactId>spring-boot-devtools</artifactId>
           <scope>runtime</scope>
           <optional>true</optional>
       </dependency>

       <dependency>
           <groupId>org.projectlombok</groupId>
           <artifactId>lombok</artifactId>
           <optional>true</optional>
       </dependency>
       <dependency>
           <groupId>org.springframework.boot</groupId>
           <artifactId>spring-boot-starter-test</artifactId>
           <scope>test</scope>
       </dependency>
    </dependencies>
~~~

~~~yml
server:
  port: 9001
~~~

启动类

~~~java
	@SpringBootApplication
@EnableHystrixDashboard
public class HystirxDasboardMain9001 {

    public static void main(String[] args) {
        SpringApplication.run(HystirxDasboardMain9001.class,args);
    }
~~~

在服务提供者8001启动类上加上下面的

![image-20200606234401789](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200606234401789.png)

---







## Geteway

#### 什么是geteway

![image-20200607092913766](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607092913766.png)

![image-20200607093145973](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607093145973.png)

![image-20200607093227898](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607093227898.png)

![image-20200607093300982](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607093300982.png)

![image-20200607093323816](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607093323816.png)

![image-20200607093413398](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607093413398.png)

![image-20200607094528013](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607094528013.png)

![image-20200607095058532](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607095058532.png)

#### 三大核心概念

路由：![image-20200607100108341](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607100108341.png)

断言![image-20200607113457775](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607113457775.png)

过滤![image-20200607113552892](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607113552892.png)

总体![image-20200607113803890](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607113803890.png)

	#### 服务流程

![image-20200607113921732](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607113921732.png)

；![image-20200607113932949](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200607113932949.png)	**核心逻辑：路由转发和  执行过滤器链**







#### Geteway9527搭建

cloud-gateway-gateway9527	

~~~xml
<dependencies>
        <!--gateway-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-gateway</artifactId>
        </dependency>
        <!--eureka-client-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
        <!-- 引入自己定义的api通用包，可以使用Payment支付Entity -->
        <dependency>
            <groupId>com.atguigu.springcloud</groupId>
            <artifactId>cloud-api-commons</artifactId>
            <version>${project.version}</version>
        </dependency>
        <!--一般基础配置类-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>
~~~

~~~yml	

server:
  port: 9527

spring:
  application:
    name: cloud-gateway
  cloud:
    gateway:	
      discovery:
        locator:
          enabled: true #开启从注册中心动态创建路由的功能，利用微服务名进行路由
      routes:
        - id: payment_routh #payment_route    #路由的ID，没有固定规则但要求唯一，建议配合服务名
          #uri: http://localhost:8001          #匹配后提供服务的路由地址
          uri: lb://cloud-payment-service #匹配后提供服务的路由地址
          predicates:
            - Path=/payment/get/**         # 断言，路径相匹配的进行路由

        - id: payment_routh2 #payment_route    #路由的ID，没有固定规则但要求唯一，建议配合服务名
          #uri: http://localhost:8001          #匹配后提供服务的路由地址
          uri: lb://cloud-payment-service #匹配后提供服务的路由地址
          predicates:
            - Path=/payment/lb/**         # 断言，路径相匹配的进行路由
            #- After=2020-02-21T15:51:37.485+08:00[Asia/Shanghai]
            #- Cookie=username,zzyy
            #- Header=X-Request-Id, \d+  # 请求头要有X-Request-Id属性并且值为整数的正则表达式

eureka:
  instance:
    hostname: cloud-gateway-service
  client: #服务提供者provider注册进eureka服务列表内
    service-url:
      register-with-eureka: true
      fetch-registry: true
      defaultZone: http://eureka7001.com:7001/eureka



~~~

启动类

~~~java
@SpringBootApplication
@EnableEurekaClient
public class GatewayMain9527 {

    public static void main(String[] args) {
        SpringApplication.run(GatewayMain9527.class,args);
    }
}

~~~

#### Gateway路由的两种配置方式

添加一个配置类

```java
@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder routeLocatorBuilder)
    {
        RouteLocatorBuilder.Builder routes = routeLocatorBuilder.routes();

        routes.route("path_route_atguigu",
                r -> r.path("/guonei")
                        .uri("http://news.baidu.com/guonei")).build();

        return routes.build();
    }
}
```



---









## **SpringCloud config分布式配置中心**

#### 概述

- 分布式系统面临的配置问题
- ![image-20200608104008426](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608104008426.png)

- 是什么
- ![image-20200608104048861](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608104048861.png)
- 怎么玩
- ![image-20200608104138114](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608104138114.png)

![image-20200608104220511](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608104220511.png)

![image-20200608104244764](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608104244764.png)

#### Config服务端配置与测试

用你自己的账号在Github上新建一个名为sprincloud-config的新Repository

将其克隆到本地

添加三个文件

![image-20200608111658863](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608111658863.png)

新建Module模块cloud-config-center-3344它既为Cloud的配置中心模块cloudConfig Center



pom

```xml
   

       <dependency>
           <groupId>org.springframework.cloud</groupId>
           <artifactId>spring-cloud-config-server</artifactId>
       </dependency>
      
 

```

yml

```yml
server:
  port: 3344
spring:
  application:
    name: cloud-config-center
  cloud:
    config:
      server:
        git:
          uri:  填写你自己的github路径
          search-paths:
           - springcloud-config
      label: master
eureka:
  client:
    service-url:
      defaultZone:  http://localhost:7001/eureka
 
```

启动类



```java

@SpringBootApplication
@EnableConfigServer
public class ConfigCenterMain3344 {
    public static void main(String[] args) {
            SpringApplication.run(ConfigCenterMain3344 .class,args);
       }
}

```



windows下修改hosts文件，增加映射   127.0.0.1 config-3344.co

#### Config客服端配置与测试

bootstrap.yml是什么

![image-20200608155851277](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608155851277.png)

新建cloud-config-client-3355

~~~xml

        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-config</artifactId>
        </dependency>
~~~

~~~yml
server:
  port: 3355

spring:
  application:
    name: config-client
  cloud:
    #Config客户端配置
    config:
      label: master #分支名称
      name: config #配置文件名称
      profile: dev #读取后缀名称   上述3个综合：master分支上config-dev.yml的配置文件被读取http://config-3344.com:3344/master/config-dev.yml
      uri: http://localhost:3344 #配置中心地址k

#rabbitmq相关配置 15672是Web管理界面的端口；5672是MQ访问的端口
  rabbitmq:
    host: localhost
    port: 5672
    username: guest
    password: guest

#服务注册到eureka地址
eureka:
  client:
    service-url:
      defaultZone: http://localhost:7001/eureka

# 暴露监控端点
management:
  endpoints:
    web:
      exposure:
        include: "*"
~~~

启动类

~~~java
@SpringBootApplication
public class ConfigClientMain3355 {
    public static void main(String[] args) {
            SpringApplication.run( ConfigClientMain3355.class,args);
       }
}
~~~

业务类

~~~java
@RestController
public class ConfigClientController {

    @Value("${config.info}")
    private String configInfo;

    @GetMapping("/configInfo")
    public String getConfigInfo(){
        return configInfo;
   }
}

~~~

![image-20200608163823405](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608163823405.png)

####config动态刷新手动版

在bootstrap.yml暴露

~~~yml
# 暴露监控端点
management:
  endpoints:
    web:
      exposure:
        include: "*"
~~~

使用curl  刷新		curl -X  POST  "http://localhost:3355/actuator/refresh“

避免了服务重启

但是服务一多的话又个问题

![image-20200608175057396](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608175057396.png)

---





## Bus消息总线

####是什么

![image-20200608203702883](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608203702883.png)



#### 能干嘛

![image-20200608204248412](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608204248412.png)



#### 为什么被称为总线

![image-20200608204324590](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608204324590.png)



#### 安装RabbitMQ

先安装Erlang：http://erlang.org/download/otp_win64_21.3.exe

rabbit:下载地址：https://dl.bintray.com/rabbitmq/all/rabbitmq-server/3.7.14/rabbitmq-server-3.7.14.exe  

进入RabbitMQ安装目录下的sbin目录

输入一下命令启动管理功能

rabbitmq-plugins enable rabbitmq_management

然后点击菜单里面启动mq

查看启动是否成功  http://localhost:15672/

输入账号密码登录

guest  guest

#### SpringCloud Bus 动态刷新全局广播

![image-20200608213134966](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608213134966.png)



新建  cloud-config-client-3366  跟3355一样

设计思想

![image-20200608214406545](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608214406545.png)



第一个不适合

![image-20200608214705729](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200608214705729.png)	



我们选择第二种设计思想

在 config-server  pom中添加依赖新依赖

给cloud-config-center-3344配置中心服务端添加消息总线支持

~~~xml
<dependency>
           <groupId>org.springframework.cloud</groupId>
           <artifactId>spring-cloud-starter-bus-amqp</artifactId>
</dependency>
~~~

```YML

rabbitmq:
    host: localhost
    port: 5672
    username: guest
    password: guest

management:
  endpoints:
    web:
      exposure:
        include: 'bus-refresh'

```

在3355 和 3366中添加同样的依赖和 yml  加上这个

~~~yml
# 暴露监控端点
management:
  endpoints:
    web:
      exposure:
        include: "*"
~~~

发送POST请求   curl -X POST "http://localhost:3344/actuator/bus-refresh";  一次发送处处生效，这个是直接刷新配置的服务端，然后自动传染给其他客户端，实现了不用重启也能生效！

**定点通知**

如果你只想通知其中某一个，例如现在只通知3355，不通知3366

公式：http://localhost:配置中心的端口号/actuator/bus-refresh/{destination}    #destination就是服务名加端口号

/bus/refresh请求不再发送到具体的服务实例上，而是发给config server并通过destination参数类指定需要更新配置的服务或实例

curl -X POST "http://localhost:3344/actuator/bus-refresh/config-client:3355";

> 通知总结
>
> ![image-20200609102526319](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609102526319.png)







---















## SpringCluod  Stream

####	为什么引入cloud stream 

![image-20200609113024364](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609113024364.png)

比如说你学的是RabbitMQ 但是你去公司用的是  ActiveMQ 就要学习新的技术，就比较耗时

引入cloud stream 就可以解决这个问题，	

>一句话：**屏蔽底层消息中间件的差异，降低切换版本，统一消息的编程模型**



#### 什么是SpringCloudStream

![image-20200609113857547](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609113857547.png)

#### Stream的设计思想

标准的MQ

![image-20200609115320731](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609115320731.png)



![image-20200609115441420](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609115441420.png)



消息通道里的消息如何被消费呢，谁负责收发处理

消息通道MessageChannel的子接口SubscribableChannel,由MessageHandler消息处理器订阅

#### 为什么用CloudStream

![image-20200609133342440](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133342440.png)



![image-20200609133411622](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133411622.png)



![image-20200609133444104](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133444104.png)

**Stream为什么能屏蔽底层差异**

![image-20200609133624826](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133624826.png)

![image-20200609133658848](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133658848.png)

![image-20200609133722376](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133722376.png)

![image-20200609133744129](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133744129.png)

![image-20200609133810335](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133810335.png)



![image-20200609133907889](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609133907889.png)

**Stream中的消息通信方式遵循了发布-订阅模式**

![image-20200609134058276](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609134058276.png)

#### Stream编码常用注解简介

Stream的标准流程图

![image-20200609134407022](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609134407022.png)

![image-20200609134420462](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609134420462.png)



Spring Cloud Stream标准流程套路

- ​	Binder   很方便的连接中间件，屏蔽差异
- Channel    通道，是队列Queue的一种抽象，在消息通讯系统中就是实现存储和转发的媒介，通过对Channel对队列进行配置
- Source和Sink   简单的可理解为参照对象是Spring Cloud Stream自身，从Stream发布消息就是输出，接受消息就是输入



**编码API和常用注解**

![image-20200609135056077](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609135056077.png)





#### 案例

案例说明：

- cloud-stream-rabbitmq-provider8801,作为生产者进行发消息模块
- cloud-stream-rabbitmq-consumer8802,作为消息接收模块
- cloud-stream-rabbitmq-consumer8803,作为消息接收模块

新建Modle  cloud-stream-rabbitmq-provider8801

依赖

```xml
<dependencies>


    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-stream-rabbit</artifactId>
    </dependency>

    <!-- https://mvnrepository.com/artifact/org.springframework.cloud/spring-cloud-starter-eureka-server -->
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
    </dependency>

    <dependency>
        <groupId>com.atguigu.springcloud</groupId>
        <artifactId>cloud-api-commons</artifactId>
        <version>${project.version}</version>
    </dependency>


    <!-- https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-actuator</artifactId>
    </dependency>


    <!-- https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-devtools -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-devtools</artifactId>
        <scope>runtime</scope>
        <optional>true</optional>
    </dependency>

    <!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>

    <!-- https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-test -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>

    </dependencies>
```

yml

```yml
server:
  port: 8801

spring:
  application:
    name: cloud-stream-provider
  cloud:
    stream:
      binders: # 在此处配置要绑定的rabbitmq的服务信息；
        defaultRabbit: # 表示定义的名称，用于于binding整合
          type: rabbit # 消息组件类型
          environment: # 设置rabbitmq的相关的环境配置
            spring:
              rabbitmq:
                host: localhost
                port: 5672
                username: guest
                password: guest
      bindings: # 服务的整合处理
        output: # 这个名字是一个通道的名称
          destination: studyExchange # 表示要使用的Exchange名称定义
          content-type: application/json # 设置消息类型，本次为json，文本则设置“text/plain”
          binder: defaultRabbit  # 设置要绑定的消息服务的具体设置

eureka:
  client: # 客户端进行Eureka注册的配置
    service-url:
      defaultZone: http://localhost:7001/eureka
  instance:
    lease-renewal-interval-in-seconds: 2 # 设置心跳的时间间隔（默认是30秒）
    lease-expiration-duration-in-seconds: 5 # 如果现在超过了5秒的间隔（默认是90秒）
    instance-id: send-8801.com  # 在信息列表时显示主机名称
    prefer-ip-address: true     # 访问的路径变为IP地址


```

启动类

```java
@SpringBootApplication
public class StreamMQMain8801 {
    public static void main(String[] args) {
       SpringApplication.run(StreamMQMain8801.class, args);
   }
}
```

业务类

service

~~~java
public interface IMessageProvider {

    public String   send();
}
~~~

实现类

~~~java
@EnableBinding(Source.class)  //定义消息渠道的推送管道
public class MessageProviderImpl implements IMessageProvider {

    private MessageChannel  output; //消息发送管道

    @Override
    public String send() {
        String serial = UUID.randomUUID().toString();
        output.send(MessageBuilder.withPayload(serial).build());
        System.out.println("*****"+serial);
        return null;
    }
}

~~~

controller

~~~java
	@RestController
public class SendMessageController {
    @Resource
    private MessageProviderImpl messageProvider;

    @GetMapping("/sendMessageg")
    public String sendMessage(){
        return messageProvider.send();
    }

}

~~~

![image-20200609152331640](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609152331640.png)



新建Model 消费者  cloud-stream-rabbitmq-consumer8802

跟上面差不多  把yml中的 output  改成input

controller

~~~java
RestController
@EnableBinding(Sink.class)
public class ReceiveMessageListenerController {

    @Value("${server.port}")
    private String  serverPort;

    @StreamListener(Sink.INPUT)
    public void input(Message<String> message){
        System.out.println("消费者1，-------" + message.getPayload() + "\t port:" + serverPort);
    }
}

~~~

新建Model 消费者  cloud-stream-rabbitmq-consumer8803

跟8802一样

![image-20200609160047727](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609160047727.png)





目前是8802/8803同时都收到了，存在重复消费问题

![image-20200609161452059](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609161452059.png)

如何解决    分组和持久化属性group  **重要**

生产实际案例

![image-20200609160650565](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609160650565.png)



**分组**

原理：微服务应用放置于同一个group中，就能够保证消息只会被其中一个应用消费一次。不同的组是可以消费的，同一个组内会发生竞争关系，只有其中一个可以消费。

8802/8803都变成不同组，group两个不同

- ​	group: atguiguA、atguiguB
- 8802  8803  修改YML  

![image-20200609161844227](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609161844227.png)



我们要8802/8803实现了轮询分组，每次只有一个消费者 8801模块的发的消息只能被8802或8803其中一个接收到，这样避免了重复消费

8802/8803都变成相同组，group两个相同



**持久化**

- 通过上述，解决了重复消费问题，再看看持久化
- 停止8802/8803并去除掉8802的分组group:atguiguA
  - 8803的分组group:atguiguA没有去掉
- 8801先发送4条信息到rabbitmq
- 先启动8802，无分组属性配置，后台没有打出来消息
- 先启动8803，有分组属性配置，后台打出来了MQ上的消息

---







## SpringCloud Sleuth分布式请求链路追踪

#### 是什么，为什么会出现这个技术？需要解决哪些问题？

 ![image-20200609200850427](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609200850427.png)

​                                                    ![image-20200609200900605](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609200900605.png)

​                                                    

​                                                    

               #### 搭建链路监控步骤

- SpringCloud从F版起已不需要自己构建Zipkin server了，只需要调用jar包即可
- https://dl.bintray.com/openzipkin/maven/io/zipkin/java/zipkin-server/
- zipkin-server-2.12.9.exec.jar
- 运行jar
  - ![image-20200609201350407](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609201350407.png)

访问：http://localhost:9411/zipkin/

​                  ![image-20200609201747523](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609201747523.png)                

> 术语

完整的调用链路

![image-20200609202109829](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609202109829.png)                                           

​        精简的上图

![image-20200609202251813](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609202251813.png)                                             

​      名词解释

- Trace:类似于树结构的Span集合，表示一条调用链路，存在唯一标识
- span:表示调用链路来源，通俗的理解span就是一次请求信息

​          使用以前的微服务进行测试

​		cloud-provider-payment8001                

添加依赖

~~~xml
<!--包含了sleuth+zipkin-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-zipkin</artifactId>
        </dependency>

~~~

~~~yml
spring:
  application:
    name: cloud-payment-service
  zipkin:
       base-url: http://localhost:9411
  sleuth:
      sampler:
        probability: 1
~~~

controller

~~~java
  @GetMapping("/payment/zipkin")
    public String paymentZipkin()
    {
        return "hi ,i'am paymentzipkin server fall back，welcome to atguigu，O(∩_∩)O哈哈~";
    }

~~~

然后在80搭建 跟上面步骤一样

controller

~~~java
  @GetMapping("/consumer/payment/zipkin")
    public String paymentZipkin()
    {
        String result = restTemplate.getForObject("http://localhost:8001"+"/payment/zipkin/", String.class);
        return result;
    }

~~~



---





## SpringCloud Alibaba入门简介

#### why会出现SpringCloud alibaba?

- Spring Cloud Netflix项目进入维护模式
- https://spring.io/blog/2018/12/12/spring-cloud-greenwich-rc1-available-now

![image-20200609215130479](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609215130479.png)

- 什么是维护模式
  - ![image-20200609215603870](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609215603870.png)

![image-20200609215648664](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609215648664.png)



![image-20200609215701962](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609215701962.png)

#### SpringCloud alibaba带来了什么？

- 是什么  https://github.com/alibaba/spring-cloud-alibaba/blob/master/README-zh.md
  - ![image-20200609215846369](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609215846369.png)

- 能干嘛
  - ![image-20200609215935844](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609215935844.png)

- 去哪下  https://github.com/alibaba/spring-cloud-alibaba/blob/master/README-zh.md

- 怎么玩

  - Sentinel：把流量作为切入点，从流量控制、熔断降级、系统负载保护等多个维度保护服务的稳定性。

    Nacos：一个更易于构建云原生应用的动态服务发现、配置管理和服务管理平台。

    RocketMQ：一款开源的分布式消息系统，基于高可用分布式集群技术，提供低延时的、高可靠的消息发布与订阅服务。

    Dubbo：Apache Dubbo™ 是一款高性能 Java RPC 框架。

    Seata：阿里巴巴开源产品，一个易于使用的高性能微服务分布式事务解决方案。

    Alibaba Cloud ACM：一款在分布式架构环境中对应用配置进行集中管理和推送的应用配置中心产品。

    Alibaba Cloud OSS: 阿里云对象存储服务（Object Storage Service，简称 OSS），是阿里云提供的海量、安全、低成本、高可靠的云存储服务。您可以在任何应用、任何时间、任何地点存储和访问任意类型的数据。

    Alibaba Cloud SchedulerX: 阿里中间件团队开发的一款分布式任务调度产品，提供秒级、精准、高可靠、高可用的定时（基于 Cron 表达式）任务调度服务。

    Alibaba Cloud SMS: 覆盖全球的短信服务，友好、高效、智能的互联化通讯能力，帮助企业迅速搭建客户触达通道。



#### SpringCloud alibaba学习资料获取

- 官网  https://spring.io/projects/spring-cloud-alibaba#overview
  - ![image-20200609220513463](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609220513463.png)

![image-20200609220531943](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609220531943.png)

- 英文  https://github.com/alibaba/spring-cloud-alibaba
- https://spring-cloud-alibaba-group.github.io/github-pages/greenwich/spring-cloud-alibaba.html
- 中文   https://github.com/alibaba/spring-cloud-alibaba/blob/master/README-zh.md



---







# SpringCloud Alibaba

## Nacos  服务注册和配置中心





#### Nacos简介

- 为什么叫Nacos
- 前四个字母分别为Naming和Configuration的前两个字母，最后的s为Service

- 是什么?
  - 一个更易于构建云原生应用的动态服务发现，配置管理和服务管理中心
  - Nacos：Dynamic Naming and Configuration Service
  - Nacos就是注册中心+配置中心的组合
  - Nacos = Eureka+Config+Bus
- 能干嘛？
  - 替代Eureka做服务注册中心
  - 替代Config做服务配置中心
- 去哪下？
  - 官网文档   ：https://nacos.io/zh-cn/index.html
  - https://spring-cloud-alibaba-group.github.io/github-pages/greenwich/spring-cloud-alibaba.html#_spring_cloud_alibaba_nacos_discovery
- 各种注册中心比较
  - ​	![image-20200609223234138](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609223234138.png)

#### 安装运行Nacos

- 本地Java8+Maven环境已经OK
- 先从官网下载Nacos, https://github.com/alibaba/nacos/releases/tag/1.1.4
- 解压安装包，直接运行bin目录下的startup.cmd
- 命令运行成功后直接访问http://localhost:8848/nacos
- 账号密码默认是Nacos
- j结果页面展示
- ![image-20200609224915519](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609224915519.png)



#### Nacos作为服务注册中心演示

- 新建Module  cloudalibaba-provider-payment9001

pom

~~~xml
<dependencies>
        <dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>

    </dependencies>

~~~

~~~yml
server:
  port: 9001

spring:
  application:
    name: nacos-payment-providere
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848

management:
  endpoint:
  endpoints:
    web:
      exposure:
        include: '*'

~~~

~~~java	

@SpringBootApplication
@EnableDiscoveryClient
public class NacosMain9001 {

    public static void main(String[] args) {
        SpringApplication.run(NacosMain9001.class,args);
    }
}

~~~

conroller

~~~java

@RestController
public class PaymentController
{
    @Value("${server.port}")
    private String serverPort;

    @GetMapping(value = "/payment/nacos/{id}")
    public String getPayment(@PathVariable("id") Integer id)
    {
        return "nacos registry, serverPort: "+ serverPort+"\t id"+id;
    }
}
 

~~~



新建cloudalibaba-provider-payment9002 跟上面一样

如果想取巧不想新建重复体力劳动，直接拷贝虚拟端口映射

![image-20200609234347567](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609234347567.png)

![image-20200609234904399](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200609234904399.png)



消费者

cloudalibaba-consumer-nacos-order83

#### 服务注册中心的对比

Nacos全景图

![image-20200610101001916](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610101001916.png)



CAP对比，nacos可以切换CP  和  AP

![image-20200610101117474](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610101117474.png)

![image-20200610101215128](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610101215128.png)

curl -X PUT '$NACOS_SERVER:8848/nacos/v1/ns/operator/switches?entry=serverMode&value=CP'





#### Nacos作为配置中心

---



##### Nacos作为配置中心-基础配置

新建Model  cloudalibaba-config-nacos-client3377

~~~xml
<dependency>
    <groupId>com.alibaba.cloud</groupId>
    <artifactId>spring-cloud-starter-alibaba-nacos-config</artifactId>
</dependency>
~~~



bootstrap.yml

~~~yml
# nacos配置
server:
  port: 3377

spring:
  application:
    name: nacos-config-client
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848 #Nacos服务注册中心地址
      config:
        server-addr: localhost:8848 #Nacos作为配置中心地址
        file-extension: yaml #指定yaml格式的配置
       


# ${spring.application.name}-${spring.profile.active}.${spring.cloud.nacos.config.file-extension}
# nacos-config-client-dev.yaml

# nacos-config-client-test.yaml   ----> config.info
~~~



application.yml

~~~yml
spring:
  profiles:
    active: dev # 表示开发环境
    #active: test # 表示测试环境
    #active: info
~~~



为什么有两个配置？

![image-20200610102747983](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610102747983.png)





**Nacos中的匹配规则**

   ~~~java
${prefix}-${spring.profile.active}.${file-extension}
   ~~~

- `prefix` 默认为 `spring.application.name` 的值，也可以通过配置项 `spring.cloud.nacos.config.prefix`来配置。
- `spring.profile.active` 即为当前环境对应的 profile，详情可以参考 [Spring Boot文档](https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-profiles.html#boot-features-profiles)。 **注意：当 `spring.profile.active` 为空时，对应的连接符 `-` 也将不存在，dataId 的拼接格式变成 `${prefix}.${file-extension}`**
- `file-exetension` 为配置内容的数据格式，可以通过配置项 `spring.cloud.nacos.config.file-extension` 来配置。目前只支持 `properties` 和 `yaml` 类型。







> 实操

![image-20200610111311357](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610111311357.png)



nacos-config-client-dev

配置对应界面：

config:
    info: nacos config center,version = 1

from nacos config center, nacos-config-client-dev.yaml, version=1

![image-20200610111401549](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610111401549.png)





小总结

![image-20200610111756289](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610111756289.png)



 Error creating bean with name 'scopedTarget.configClientController': Injection of autowired dependencies failed; nested exception is java.lang.IllegalArgumentException: Could not resolve placeholder 'config.info' in value "${config.info}"

启动的时候会报这么一个错  是因为文件名不对 ，我们把nacos的配置文件改成yaml  

​        

**Nacos自带动态配置刷新**



  #### Nacos作为配置中心-分类配置

 问题？

![image-20200610142527029](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610142527029.png)                                                 

Nacos的图形化管理界面

![image-20200610142657554](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610142657554.png)



![image-20200610142711193](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610142711193.png)



Namespace+Group+Data ID三者关系？为什么这么设计？

![image-20200610142745433](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610142745433.png)





![image-20200610142753178](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610142753178.png)

DataID方案：

指定spring.profile.active和配置文件的DataID来使不同环境下读取不同的配置

默认空间+默认分组+新建dev和test两个DataID

![image-20200610143529965](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610143529965.png)

​	



Group方案

![image-20200610153503357](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610153503357.png)

在nacos图形界面控制台上面新建配置文件DataID

![image-20200610153526736](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610153526736.png)

bootstrap+application

![image-20200610153548418](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610153548418.png)



namespance

![image-20200610160201918](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610160201918.png)

回到服务管理-服务列表查看

![image-20200610160219966](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610160219966.png)

按照域名配置填写

![image-20200610160239046](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610160239046.png)在bootstrap中加入namespance  :   id

---





#### ==**Nacos集群和持久化配置**==



##### Nacos架构集群说明



官网说明

- ​	https://nacos.io/zh-cn/docs/cluster-mode-quick-start.html

- 官网架构图（写的(┬＿┬)）![image-20200610172030911](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610172030911.png)

- 上图官网翻译，真实情况![image-20200610172105541](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610172105541.png)

  ​					

![image-20200610172214664](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610172214664.png)



​                            说明

![image-20200610172241232](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610172241232.png)                                    

![image-20200610172249475](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610172249475.png)

![image-20200610172302515](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610172302515.png)







#### Nacos持久化配置切换

Nacos默认自带的是嵌入式数据库derby，，https://github.com/alibaba/nacos/blob/develop/config/pom.xml

derby到mysql切换配置步骤

- nacos-server-1.1.4\nacos\conf目录下找到sql脚本

- nacos-mysql.sql

- 创建  nacos_config  数据库 然后倒入sql文件

- nacos-server-1.1.4\nacos\conf目录下找到application.properties

- 在里面添加

  ~~~properties
  spring.datasource.platform=mysql
  
  db.num=1
  db.url.0=jdbc:mysql://localhost:3306/nacos_config?characterEncoding=utf8&connectTimeout=1000&socketTimeout=3000&autoReconnect=true
  db.user=root
  db.passwor=1234
  ~~~

重启Nacos





#### Linux版Nacos+MySQL生产环境配置

预计需要，1个nginx+3个nacos注册中心+1个mysql

- Nacos下载linux版本
- https://github.com/alibaba/nacos/releases/tag/1.1.4

解压后拷贝它到另一个文件夹，这样就两个了



#### 集群配置步骤

![image-20200610210716931](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610210716931.png)

sql语句源文件  nacos-mysql.sql

自己Linux机器上的Mysql数据库黏贴

![image-20200610210751019](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200610210751019.png)	



Linux服务器上nacos的集群配置cluster.conf

cp cluster.conf.example cluster.conf  使用 cluster.conf

![image-20200611101402812](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611101402812.png)

梳理出3台nacos机器的不同服务端口号

![image-20200611101435839](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611101435839.png)

须是Linux命令hostname -i能够识别的IP

编辑Nacos的启动脚本startup.sh，使它能够接受不同的启动端

/mynacos/nacos/bin目录下有startup.sh

![image-20200611103509341](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611103509341.png)



​	![image-20200611103535466](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611103535466.png)



![image-20200611103548270](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611103548270.png)



![image-20200611103602494](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611103602494.png)





![image-20200611103621857](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611103621857.png)

高可用小总结

![image-20200611203714287](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611203714287.png)





---















## Sentinel实现熔断与限流

####简介

官网：https://github.com/alibaba/Sentinel

中文：https://github.com/alibaba/Sentinel/wiki/%E4%BB%8B%E7%BB%8D

是什么：![image-20200611204846562](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611204846562.png)

能干嘛

![image-20200611204908499](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611204908499.png)

怎么玩

https://spring-cloud-alibaba-group.github.io/github-pages/greenwich/spring-cloud-alibaba.html#_spring_cloud_alibaba_sentinel

服务使用中的各种问题![image-20200611204948418](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611204948418.png)



#### 安装

Sentinel由两部分组成

![image-20200611212855386](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200611212855386.png)



下载

https://github.com/alibaba/Sentinel/releases

下载到本地sentinel-dashboard-1.7.0.jar

java8环境OK

8080端口不能被占用

java -jar sentinel-dashboard-1.7.0.jar 

http://localhost:8080

登录账号密码均为sentinel

#### 初始化演示工程

创建cloudalibaba-sentinel-service8401

~~~xml
 <dependency>
            <groupId>com.atguigu.springcloud</groupId>
            <artifactId>cloud-api-commons</artifactId>
            <version>${project.version}</version>
        </dependency>

        <dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
        </dependency>

        <dependency>
            <groupId>com.alibaba.csp</groupId>
            <artifactId>sentinel-datasource-nacos</artifactId>
        </dependency>

        <dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-sentinel</artifactId>
        </dependency>

~~~

~~~yml
server:
  port: 8401

spring:
  application:
    name: cloudalibaba-sentinel-service
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848
    sentinel:
      transport:
        dashboard: localhost:8080
        port: 8719  #默认8719，假如被占用了会自动从8719开始依次+1扫描。直至找到未被占用的端口

management:
  endpoints:
    web:
      exposure:
        include: '*'

~~~

启动Sentinel

java -jar sentinel-dashboard-1.7.0

启动微服务8401

空空如也，啥都没有

Sentinel采用的懒加载机制，执行一次访问即可让sentinel知道你来过！

#### 流量控制

![image-20200612103304592](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612103304592.png)

![image-20200612103317914](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612103317914.png)

##### 流量模式

**直接->快速失败    系统默认**

![image-20200612104102216](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612104102216.png)

快速点击访问http://localhost:8401/testA

Blocked by Sentinel (flow limiting)

思考？？？？  直接调用默认报错信息，技术方面OK but，是否应该有我们自己的后续处理？

类似有一个fallback的兜底方法？



线程数：

QPS是只要你达到阈值就直接报错，但是线程数是先放进来能处理就处理，处理不了就报错

![image-20200612105748051](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612105748051.png)

![image-20200612105928132](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612105928132.png)

当你值访问一次的时候进去，只有一个线程池进行处理，但是你连续访问，线程池就会处理不过来然后报错

![image-20200612110106960](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612110106960.png)

**关联模式**

当关联的资源达到阈值时，就限流自己

当与A关联的资源B达到阈值后，就限流自己，B惹事，A挂了

![image-20200612112144844](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612112144844.png)

postman模拟并发密集访问testB

![image-20200612112207714](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612112207714.png)

![image-20200612112240573](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612112240573.png)

postman里新建多线程集合组

![image-20200612112303082](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612112303082.png)

将访问地址添加进新线程组

![image-20200612112345639](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612112345639.png)

大批量线程高并发访问B，导致A失效了

---





#### 流控效果

直接->快速失败（默认的流控处理）直接失败，抛出异常  Blocked by Sentinel (flow limiting)

com.alibaba.csp.sentinel.slots.block.flow.controller.DefaultController

预热：公式：阈值除以coldFactor（默认值为3），经过预热时长后才会达到阈值

默认coldFactor为3，即请求QPS从threshold/3开始，经预热时长逐渐升至设定的QPS阈值。

限流：冷启动：https://github.com/alibaba/Sentinel/wiki/%E9%99%90%E6%B5%81---%E5%86%B7%E5%90%AF%E5%8A%A8

预热配置

![image-20200612145506238](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612145506238.png)





排队等待

![image-20200612172240575](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612172240575.png)



官网：com.alibaba.csp.sentinel.slots.block.flow.controller.RateLimiterController



![image-20200612172427866](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612172427866.png)







#### 降级规则

基本介绍

![image-20200612203126088](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612203126088.png)



半开的状态系统自动去检测是否请求有异常，没有异常就关闭断路器恢复使用，有异常则继续打开断路器不可用。具体可以参考Hystrix

Sentinel的断路器是没有半开状态的





降级策略实战

![image-20200612203219093](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612203219093.png)



![image-20200612203334806](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612203334806.png)





    @GetMapping("/testD")
    public String testD()
    {
        try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException e) { e.printStackTrace(); }
        log.info("testD 测试RT");
    
        return "------testD";
    }

 

![image-20200612203413707](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612203413707.png)



​		jmeter压测

结论

![image-20200612203434456](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612203434456.png)





异常比例

![image-20200612211003463](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612211003463.png)	![image-20200612211011806](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612211011806.png)



![image-20200612211038580](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612211038580.png)





![image-20200612211105265](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612211105265.png)





![image-20200612211115168](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612211115168.png)





异常数

![image-20200612211234194](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612211234194.png)

![image-20200612211254402](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612211254402.png)



![image-20200612211326398](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612211326398.png)









#### 热点key限流

基本介绍

![image-20200612221648625](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612221648625.png)







https://github.com/alibaba/Sentinel/wiki/热点参数限流



配置

@SentinelResource(value = "testHotKey")

异常打到了前台用户界面看不到，不友好

@SentinelResource(value = "testHotKey",blockHandler = "deal_testHotKey")

方法testHostKey里面第一个参数只要QPS超过每秒1次，马上降级处理

用了我们自己定义的

![image-20200612221811377](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200612221811377.png)





#### 系统规则

https://github.com/alibaba/Sentinel/wiki/%E7%B3%BB%E7%BB%9F%E8%87%AA%E9%80%82%E5%BA%94%E9%99%90%E6%B5%81

各项配置参数说明

![image-20200613094329638](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613094329638.png)

这都是配置全局的



#### @SentinelResource

客户自定义限流处理逻辑

创建customerBlockHandler类用于自定义限流处理逻辑

~~~java
public class CustomerBlockHandler {

    public static CommonResult handleException(BlockException exception) {
        return new CommonResult(2020, "自定义限流处理信息....CustomerBlockHandler");

    }
}
 
~~~

controller

~~~java
@GetMapping("/rateLimit/customerBlockHandler")
@SentinelResource(value = "customerBlockHandler",
        blockHandlerClass = CustomerBlockHandler.class,
        blockHandler = "handlerException2")
public CommonResult customerBlockHandler()
{
    return new CommonResult(200,"按客戶自定义",new Payment(2020L,"serial003"));
}
 

~~~

启动微服务后先调用一次

![image-20200613104146070](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613104146070.png)

Sentinel主要有三个核心API

![image-20200613104220218](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613104220218.png)

`@SentinelResource` 用于定义资源，并提供可选的异常处理和 fallback 配置项。 `@SentinelResource` 注解包含以下属性：

- `value`：资源名称，必需项（不能为空）

- `entryType`：entry 类型，可选项（默认为 `EntryType.OUT`）

- `blockHandler` / `blockHandlerClass`: `blockHandler` 对应处理 `BlockException` 的函数名称，可选项。blockHandler 函数访问范围需要是 `public`，返回类型需要与原方法相匹配，参数类型需要和原方法相匹配并且最后加一个额外的参数，类型为 `BlockException`。blockHandler 函数默认需要和原方法在同一个类中。若希望使用其他类的函数，则可以指定 `blockHandlerClass` 为对应的类的 `Class` 对象，注意对应的函数必需为 static 函数，否则无法解析。

- ```
  fallback
  ```

  ：fallback 函数名称，可选项，用于在抛出异常的时候提供 fallback 处理逻辑。fallback 函数可以针对所有类型的异常（除了

   

  ```
  exceptionsToIgnore
  ```

   

  里面排除掉的异常类型）进行处理。fallback 函数签名和位置要求：

  - 返回值类型必须与原函数返回值类型一致；
  - 方法参数列表需要和原函数一致，或者可以额外多一个 `Throwable` 类型的参数用于接收对应的异常。
  - fallback 函数默认需要和原方法在同一个类中。若希望使用其他类的函数，则可以指定 `fallbackClass` 为对应的类的 `Class` 对象，注意对应的函数必需为 static 函数，否则无法解析。

- ```
  defaultFallback
  ```

  （since 1.6.0）：默认的 fallback 函数名称，可选项，通常用于通用的 fallback 逻辑（即可以用于很多服务或方法）。默认 fallback 函数可以针对所以类型的异常（除了

   

  ```
  exceptionsToIgnore
  ```

   

  里面排除掉的异常类型）进行处理。若同时配置了 fallback 和 defaultFallback，则只有 fallback 会生效。defaultFallback 函数签名要求：

  - 返回值类型必须与原函数返回值类型一致；
  - 方法参数列表需要为空，或者可以额外多一个 `Throwable` 类型的参数用于接收对应的异常。
  - defaultFallback 函数默认需要和原方法在同一个类中。若希望使用其他类的函数，则可以指定 `fallbackClass` 为对应的类的 `Class` 对象，注意对应的函数必需为 static 函数，否则无法解析。

- `exceptionsToIgnore`（since 1.6.0）：用于指定哪些异常被排除掉，不会计入异常统计中，也不会进入 fallback 逻辑中，而是会原样抛出。

> 注：1.6.0 之前的版本 fallback 函数只针对降级异常（`DegradeException`）进行处理，**不能针对业务异常进行处理**。



---



#### 服务熔断功能

##### Ribbon和OpenFeign系列

sentinel整合ribbon+openFeign+fallback

启动nacos和sentinel

新建cloudalibaba-provider-payment9003/9004

```xml
<dependencies>
    <!--SpringCloud ailibaba nacos -->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
    </dependency>
    <dependency><!-- 引入自己定义的api通用包，可以使用Payment支付Entity -->
        <groupId>com.atguigu.springcloud</groupId>
        <artifactId>cloud-api-commons</artifactId>
        <version>${project.version}</version>
    </dependency>
    <!-- SpringBoot整合Web组件 -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-actuator</artifactId>
    </dependency>
    <!--日常通用jar包配置-->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-devtools</artifactId>
        <scope>runtime</scope>
        <optional>true</optional>
    </dependency>
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
 

```

~~~yml
server:
  port: 9003

spring:
  application:
    name: nacos-payment-provider
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848 #配置Nacos地址

management:
  endpoints:
    web:
      exposure:
        include: '*'


~~~



新建cloudalibaba-consumer-nacos-order84

```xml
<dependencies>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-openfeign</artifactId>
        </dependency>
        <dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
        </dependency>
        <dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-sentinel</artifactId>
        </dependency>
        <dependency>
            <groupId>com.atguigu.springcloud</groupId>
            <artifactId>cloud-api-commons</artifactId>
            <version>${project.version}</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

```

~~~yml
server:
  port: 84


spring:
  application:
    name: nacos-order-consumer
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848
    sentinel:
      transport:
        dashboard: localhost:8080
        port: 8719

service-url:
  nacos-user-service: http://nacos-payment-provider
 

~~~

修改后请重启微服务修改后请重启微服务

热部署对java代码级生效及时

对@SentinelResource注解内属性，有时效果不好

~~~java
package com.atguigu.springcloud.alibaba.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.csp.sentinel.slots.block.BlockException;
import com.atguigu.springcloud.alibaba.entities.CommonResult;
import com.atguigu.springcloud.alibaba.entities.Payment;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;


@RestController
@Slf4j
public class CircleBreakerController {
   
    public static final String SERVICE_URL = "http://nacos-payment-provider";

    @Resource
    private RestTemplate restTemplate;

   
    
    @RequestMapping("/consumer/fallback/{id}")
    //@SentinelResource(value = "fallback") //没有配置
    //@SentinelResource(value = "fallback",fallback = "handlerFallback") //fallback只负责业务异常
    //@SentinelResource(value = "fallback",blockHandler = "blockHandler") //blockHandler只负责sentinel控制台配置违规
    @SentinelResource(value = "fallback",fallback = "handlerFallback",blockHandler = "blockHandler",
            exceptionsToIgnore = {IllegalArgumentException.class})
    public CommonResult<Payment> fallback(@PathVariable Long id) {
        CommonResult<Payment> result = restTemplate.getForObject(SERVICE_URL + "/paymentSQL/"+id, CommonResult.class,id);

        if (id == 4) {
            throw new IllegalArgumentException ("IllegalArgumentException,非法参数异常....");
        }else if (result.getData() == null) {
            throw new NullPointerException ("NullPointerException,该ID没有对应记录,空指针异常");
        }

        return result;
    }
  
    //fallback
    public CommonResult handlerFallback(@PathVariable  Long id,Throwable e) {
        Payment payment = new Payment(id,"null");
        return new CommonResult<>(444,"兜底异常handlerFallback,exception内容  "+e.getMessage(),payment);
    }
  
    //blockHandler
    public CommonResult blockHandler(@PathVariable  Long id,BlockException blockException) {
        Payment payment = new Payment(id,"null");
        return new CommonResult<>(445,"blockHandler-sentinel限流,无此流水: blockException  "+blockException.getMessage(),payment);
    }


}
 
 

~~~

测试地址: http://localhost:84/consumer/fallback/1

fallback管运行异常

blockHandler管配置违规

![image-20200613202731558](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613202731558.png)



熔断框架比较

![image-20200613210234497](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613210234497.png)







#### 持久化规则

修改cloudalibaba-sentinel-service8401

<dependency>
    <groupId>com.alibaba.csp</groupId>
    <artifactId>sentinel-datasource-nacos</artifactId>
</dependency>

~~~yml
spring:
  application:
    name: cloudalibaba-sentinel-service
  cloud:
    nacos:
      discovery:
        server-addr: localhost:8848 #Nacos服务注册中心地址
    sentinel:
      transport:
        dashboard: localhost:8080 #配置Sentinel dashboard地址
        port: 8719
      datasource:
        ds1:
          nacos:
            server-addr: localhost:8848
            dataId: cloudalibaba-sentinel-service
            groupId: DEFAULT_GROUP
            data-type: json
            rule-type: flow

~~~





添加Nacos业务配置规则

![image-20200613215038916](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613215038916.png)



![image-20200613215049472](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613215049472.png)



内容解析

~~~json
[
    {
         "resource": "/retaLimit/byUrl",
         "limitApp": "default",
         "grade":   1,
         "count":   1,
         "strategy": 0,
         "controlBehavior": 0,
         "clusterMode": false    
    }
]

~~~



![image-20200613215124713](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613215124713.png)



启动8401后刷新sentinel发现业务规则有了

![image-20200613215144833](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613215144833.png)



停止8401再看

![image-20200613215213448](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200613215213448.png)

重新启动8401再看sentinel

扎一看还是没有，稍等一会儿

多次调用

重新配置出现了，持久化验证通过





---







## Seata处理分布式事务

#### 分布式事务问题

分布式前，单机单库没这个问题

从1：1 -> 1:N -> N: N

分布式之后：![image-20200614094019856](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200614094019856.png)



![image-20200614094029405](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200614094029405.png)



一次业务操作需要跨多个数据源或需要跨多个系统进行远程调用，就会产生分布式事务问题



#### Seata简介

是什么：Seata是一款开源的分布式事务解决方案，致力于在微服务架构下提供高性能和简单易用的分布式事务服务

官网：http://seata.io/zh-cn/

**能干嘛：一个典型的分布式事务过程   --分布式事务处理过程的-ID+三组件模型**

**Transaction ID XID**

**三个组件的概念**

**Transaction Coordinator(TC) ：事务协调器，维护全局事务的运行状态，负责协调并驱动全局事务的提交或回滚;**

**Transaction  Manager(TM) ：控制全局事务的边界，负责开启一个全局事务，并最终发起全局提交或全局回滚的决议;**

**Resource Manager(RM) ：控制分支事务，负责分支注册，状态汇报，并接收事务协调器的指令，驱动分支（本地）事务的提交和回滚；**

**处理过程**

![image-20200614095658701](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200614095658701.png)

![image-20200614095713055](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200614095713055.png)





#### 下载安装

下载地址：发布说明:https://github.com/seata/seata/releases

seata-server-0.9.0.zip解压到指定目录并修改conf目录下的file.conf配置文件

先备份原始file.conf文件

主要修改：自定义事务组名称+事务日志存储模式为db+数据库连接信息

file.conf

service模块：vgroup_mapping.my_test_tx_group = "fsp_tx_group"

store模块：

~~~properties
mode = "db"
 
  url = "jdbc:mysql://127.0.0.1:3306/seata"
  user = "root"
  password = "你自己的密码"

~~~

4.mysql5.7数据库新建库seata

建表db_store.sql在\seata-server-0.9.0\seata\conf目录里面

~~~sql
-- the table to store GlobalSession data
drop table if exists `global_table`;
create table `global_table` (
  `xid` varchar(128)  not null,
  `transaction_id` bigint,
  `status` tinyint not null,
  `application_id` varchar(32),
  `transaction_service_group` varchar(32),
  `transaction_name` varchar(128),
  `timeout` int,
  `begin_time` bigint,
  `application_data` varchar(2000),
  `gmt_create` datetime,
  `gmt_modified` datetime,
  primary key (`xid`),
  key `idx_gmt_modified_status` (`gmt_modified`, `status`),
  key `idx_transaction_id` (`transaction_id`)
);
 
-- the table to store BranchSession data
drop table if exists `branch_table`;
create table `branch_table` (
  `branch_id` bigint not null,
  `xid` varchar(128) not null,
  `transaction_id` bigint ,
  `resource_group_id` varchar(32),
  `resource_id` varchar(256) ,
  `lock_key` varchar(128) ,
  `branch_type` varchar(8) ,
  `status` tinyint,
  `client_id` varchar(64),
  `application_data` varchar(2000),
  `gmt_create` datetime,
  `gmt_modified` datetime,
  primary key (`branch_id`),
  key `idx_xid` (`xid`)
);
 
-- the table to store lock data
drop table if exists `lock_table`;
create table `lock_table` (
  `row_key` varchar(128) not null,
  `xid` varchar(96),
  `transaction_id` long ,
  `branch_id` long,
  `resource_id` varchar(256) ,
  `table_name` varchar(32) ,
  `pk` varchar(36) ,
  `gmt_create` datetime ,
  `gmt_modified` datetime,
  primary key(`row_key`)
);
 

~~~

修改seata-server-0.9.0\seata\conf目录下的registry.conf配置文件

~~~properties
registry {
  # file 、nacos 、eureka、redis、zk、consul、etcd3、sofa
  type = "nacos"	
 
  nacos {
    serverAddr = "localhost:8848"
    namespace = ""	
    cluster = "default"
  }

~~~

目的是：指明注册中心为nacos，及修改nacos连接信息

先启动Nacos端口号8848

再启动seata-server

softs\seata-server-0.9.0\seata\bin,seata-server.bat

#### 订单/库存/账户业务数据库准备

以下演示都需要先启动Nacos后启动Seata，保证两个都OK

Seata没启动报错no available server to connect

分布式事务业务说明:

![image-20200615092456611](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200615092456611.png)

下订单-->扣库存-->减账户（余额）

seata_order: 存储订单的数据库

seata_storage:存储库存的数据库

seata_account: 存储账户信息的数据库

建库SQL

~~~sql
CREATE DATABASE seata_order；
 
CREATE DATABASE seata_storage；
 
CREATE DATABASE seata_account；

~~~



按照上述3库分别建对应业务表

seata_order库下建t_order表

````sql
CREATE TABLE t_order(
    `id` BIGINT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT(11) DEFAULT NULL COMMENT '用户id',
    `product_id` BIGINT(11) DEFAULT NULL COMMENT '产品id',
    `count` INT(11) DEFAULT NULL COMMENT '数量',
    `money` DECIMAL(11,0) DEFAULT NULL COMMENT '金额',
    `status` INT(1) DEFAULT NULL COMMENT '订单状态：0：创建中; 1：已完结'
) ENGINE=INNODB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
 
SELECT * FROM t_order;

````

seata_storage库下建t_storage表

```sql
CREATE TABLE t_storage(
    `id` BIGINT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `product_id` BIGINT(11) DEFAULT NULL COMMENT '产品id',
    `total` INT(11) DEFAULT NULL COMMENT '总库存',
    `used` INT(11) DEFAULT NULL COMMENT '已用库存',
    `residue` INT(11) DEFAULT NULL COMMENT '剩余库存'
) ENGINE=INNODB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
 
INSERT INTO seata_storage.t_storage(`id`,`product_id`,`total`,`used`,`residue`)
VALUES('1','1','100','0','100');
 
 
SELECT * FROM t_storage;

```

seata_account库下建t_account表

```sql
CREATE TABLE t_account(
    `id` BIGINT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT 'id',
    `user_id` BIGINT(11) DEFAULT NULL COMMENT '用户id',
    `total` DECIMAL(10,0) DEFAULT NULL COMMENT '总额度',
    `used` DECIMAL(10,0) DEFAULT NULL COMMENT '已用余额',
    `residue` DECIMAL(10,0) DEFAULT '0' COMMENT '剩余可用额度'
) ENGINE=INNODB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
 
INSERT INTO seata_account.t_account(`id`,`user_id`,`total`,`used`,`residue`) VALUES('1','1','1000','0','1000')
 
 
 
SELECT * FROM t_account;

```



按照上述3库分别建对应的回滚日志表

订单-库存-账户3个库下都需要建各自的回滚日志表	

\seata-server-0.9.0\seata\conf目录下的db_undo_log.sql 

```sql
drop table `undo_log`;
CREATE TABLE `undo_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branch_id` bigint(20) NOT NULL,
  `xid` varchar(100) NOT NULL,
  `context` varchar(128) NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int(11) NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

```

最终效果

![image-20200615094205870](D:\MarkdownNote\SpringCloud\SpringCloud.assets\image-20200615094205870.png)





#### 订单/库存/账户业务微服务准备

下订单->减库存->扣余额->改（订单）状态

新建订单Order-Module

seata-order-service2001

file.conf

~~~properties
transport {
  # tcp udt unix-domain-socket
  type = "TCP"
  #NIO NATIVE
  server = "NIO"
  #enable heartbeat
  heartbeat = true
  # the client batch send request enable
  enableClientBatchSendRequest = false
  #thread factory for netty
  threadFactory {
    bossThreadPrefix = "NettyBoss"
    workerThreadPrefix = "NettyServerNIOWorker"
    serverExecutorThreadPrefix = "NettyServerBizHandler"
    shareBossWorker = false
    clientSelectorThreadPrefix = "NettyClientSelector"
    clientSelectorThreadSize = 1
    clientWorkerThreadPrefix = "NettyClientWorkerThread"
    # netty boss thread size,will not be used for UDT
    bossThreadSize = 1
    #auto default pin or 8
    workerThreadSize = "default"
  }
  shutdown {
    # when destroy server, wait seconds
    wait = 3
  }
  serialization = "seata"
  compressor = "none"
}
# service configuration, only used in client side
service {
  #transaction service group mapping
  vgroupMapping.my_fsp_tx_group = "default"
  #only support when registry.type=file, please don't set multiple addresses
  default.grouplist = "127.0.0.1:8091"
  #degrade, current not support
  enableDegrade = false
  #disable seata
  disableGlobalTransaction = false
}
#client transaction configuration, only used in client side
client {
  rm {
    asyncCommitBufferLimit = 10000
    lock {
      retryInterval = 10
      retryTimes = 30
      retryPolicyBranchRollbackOnConflict = true
    }
    reportRetryCount = 5
    tableMetaCheckEnable = false
    reportSuccessEnable = false
    sqlParserType = druid
  }
  tm {
    commitRetryCount = 5
    rollbackRetryCount = 5
  }
  undo {
    dataValidation = true
    logSerialization = "jackson"
    logTable = "undo_log"
  }
  log {
    exceptionRate = 100
  }
}

## transaction log store, only used in server side
store {
  ## store mode: file、db
  mode = "db"
  ## file store property
  file {
    ## store location dir
    dir = "sessionStore"
    # branch session size , if exceeded first try compress lockkey, still exceeded throws exceptions
    maxBranchSessionSize = 16384
    # globe session size , if exceeded throws exceptions
    maxGlobalSessionSize = 512
    # file buffer size , if exceeded allocate new buffer
    fileWriteBufferCacheSize = 16384
    # when recover batch read size
    sessionReloadReadSize = 100
    # async, sync
    flushDiskMode = async
  }

  ## database store property
  db {
    ## the implement of javax.sql.DataSource, such as DruidDataSource(druid)/BasicDataSource(dbcp) etc.
    datasource = "dbcp"
    ## mysql/oracle/h2/oceanbase etc.
    dbType = "mysql"
    driverClassName = "com.mysql.jdbc.Driver"
    url = "jdbc:mysql://127.0.0.1:3306/seata"
    user = "root"
    password = "1234"
    minConn = 1
    maxConn = 10
    globalTable = "global_table"
    branchTable = "branch_table"
    lockTable = "lock_table"
    queryLimit = 100
  }
}
## server configuration, only used in server side
server {
  recovery {
    #schedule committing retry period in milliseconds
    committingRetryPeriod = 1000
    #schedule asyn committing retry period in milliseconds
    asynCommittingRetryPeriod = 1000
    #schedule rollbacking retry period in milliseconds
    rollbackingRetryPeriod = 1000
    #schedule timeout retry period in milliseconds
    timeoutRetryPeriod = 1000
  }
  undo {
    logSaveDays = 7
    #schedule delete expired undo_log in milliseconds
    logDeletePeriod = 86400000
  }
  #unit ms,s,m,h,d represents milliseconds, seconds, minutes, hours, days, default permanent
  maxCommitRetryTimeout = "-1"
  maxRollbackRetryTimeout = "-1"
  rollbackRetryTimeoutUnlockEnable = false
}

## metrics configuration, only used in server side
metrics {
  enabled = false
  registryType = "compact"
  # multi exporters use comma divided
  exporterList = "prometheus"
  exporterPrometheusPort = 9898
}
~~~

registry.conf

~~~properties
registry {
  # file 、nacos 、eureka、redis、zk、consul、etcd3、sofa
  type = "nacos"
 
  nacos {
    serverAddr = "localhost:8848"
    namespace = ""
    cluster = "default"
  }
  eureka {
    serviceUrl = "http://localhost:8761/eureka"
    application = "default"
    weight = "1"
  }
  redis {
    serverAddr = "localhost:6379"
    db = "0"
  }
  zk {
    cluster = "default"
    serverAddr = "127.0.0.1:2181"
    session.timeout = 6000
    connect.timeout = 2000
  }
  consul {
    cluster = "default"
    serverAddr = "127.0.0.1:8500"
  }
  etcd3 {
    cluster = "default"
    serverAddr = "http://localhost:2379"
  }
  sofa {
    serverAddr = "127.0.0.1:9603"
    application = "default"
    region = "DEFAULT_ZONE"
    datacenter = "DefaultDataCenter"
    cluster = "default"
    group = "SEATA_GROUP"
    addressWaitTime = "3000"
  }
  file {
    name = "file.conf"
  }
}
 
config {
  # file、nacos 、apollo、zk、consul、etcd3
  type = "file"
 
  nacos {
    serverAddr = "localhost"
    namespace = ""
  }
  consul {
    serverAddr = "127.0.0.1:8500"
  }
  apollo {
    app.id = "seata-server"
    apollo.meta = "http://192.168.1.204:8801"
  }
  zk {
    serverAddr = "127.0.0.1:2181"
    session.timeout = 6000
    connect.timeout = 2000
  }
  etcd3 {
    serverAddr = "http://localhost:2379"
  }
  file {
    name = "file.conf"
  }
}

~~~

domain

```java

 
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommonResult<T>
{
    private Integer code;
    private String  message;
    private T       data;
 
    public CommonResult(Integer code, String message)
    {
        this(code,message,null);
    }
}
 

```

```java

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order
{
    private Long id;
 
    private Long userId;
 
    private Long productId;
 
    private Integer count;
 
    private BigDecimal money;
 
    private Integer status; //订单状态：0：创建中；1：已完结
}
 

```

启动类

```java
@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)//取消数据源自动创建的配置
public class SeataOrderMainApp2001{
 
    public static void main(String[] args)
    {
        SpringApplication.run(SeataOrderMainApp2001.class, args);
    }
}

```



dao

```java
@Mapper
public interface OrderDao {

    //新建订单
    void create(Order order);

    //修改订单状态 从零改为1
    void  update(@Param("userId")Long userId,@Param("status") Integer status);
}
```



OrderMapper.xml

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd" >
 
<mapper namespace="com.atguigu.springcloud.dao.OrderDao">
 
    <resultMap id="BaseResultMap" type="com.atguigu.springcloud.alibaba.domain.Order">
        <id column="id" property="id" jdbcType="BIGINT"/>
        <result column="user_id" property="userId" jdbcType="BIGINT"/>
        <result column="product_id" property="productId" jdbcType="BIGINT"/>
        <result column="count" property="count" jdbcType="INTEGER"/>
        <result column="money" property="money" jdbcType="DECIMAL"/>
        <result column="status" property="status" jdbcType="INTEGER"/>
    </resultMap>
 
    <insert id="create">
        insert into t_order (id,user_id,product_id,count,money,status)
        values (null,#{userId},#{productId},#{count},#{money},0);
    </insert>
 
 
    <update id="update">
        update t_order set status = 1
        where user_id=#{userId} and status = #{status};
    </update>
 
</mapper>
 

```











